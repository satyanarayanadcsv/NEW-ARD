package com.cg.airline.dao;

import java.util.ArrayList;
import java.util.Date;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.beans.AirLineFlightInfoDTO;
import com.cg.airline.exception.AirLineException;

public interface IAirLineDAO {
	public void bookTicket(AirLineBookInfoDTO dto) throws AirLineException;
	public ArrayList<AirLineFlightInfoDTO> showFlights(String src_city, String dest_city,Date booking_date) throws AirLineException;
	public Double findFirstSeatFare(String flightno) throws AirLineException;
	public Double findBusSeatFare(String flightno) throws AirLineException;
	public int getBookingid() throws AirLineException;
	public void updateSeats(String string,String class_type,int no_of_passengers)
			throws AirLineException;
	boolean validUser(String username, String password, String role)
			throws AirLineException;
	ArrayList<AirLineBookInfoDTO> showTicket(int bookingID)
			throws AirLineException;
	public void addFlight(AirLineFlightInfoDTO addFlightDto)
			throws AirLineException;
	public void deleteFlight(String flightno) throws AirLineException;
	public ArrayList<AirLineFlightInfoDTO> viewSchedule() throws AirLineException;
	public void updateCity(String flightno, String src_city, String dest_city)
			throws AirLineException;
	public void updateDate(String flightno, Date dep_date, Date arr_date)
			throws AirLineException;
	public void updateTime(String flightno, String dep_time, String arr_time)
			throws AirLineException;
}