package com.cg.airline.exception;

@SuppressWarnings("serial")
public class AirLineException extends Exception{
	public AirLineException(String msg) {
		super(msg);
	}
}
