package com.cg.airline.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.beans.AirLineFlightInfoDTO;
import com.cg.airline.exception.AirLineException;
import com.cg.airline.util.DBconnection;

public class AirLineDAOImpl implements IAirLineDAO {

	@Override
	public void bookTicket(AirLineBookInfoDTO dto) throws AirLineException {

		Connection conn;
		PreparedStatement insertStmt;
		try {

			conn = DBconnection.getConnection();
			insertStmt = conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			insertStmt.setString(1, dto.getCust_email());
			insertStmt.setInt(2, dto.getNo_of_passengers());
			insertStmt.setString(3, dto.getClass_type());
			insertStmt.setDouble(4, dto.getTotal_fare());
			insertStmt.setString(5, dto.getSeat_number());
			insertStmt.setString(6, dto.getCustomer_names());
			insertStmt.setString(7, dto.getCreditcard_info());
			insertStmt.setString(8, dto.getSrc_city());
			insertStmt.setString(9, dto.getDest_city());
			insertStmt.setString(10, dto.getFlightno());
			insertStmt.setDate(11, new java.sql.Date(dto.getBooking_date()
					.getTime()));

			int set = insertStmt.executeUpdate();
			if (set != 1) {
				throw new AirLineException(
						"Sorry can not proccess your request");
			} else {
				System.out.println("Successfully Saved Booking Details");
				conn.commit();
				insertStmt.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	@Override
	public ArrayList<AirLineFlightInfoDTO> showFlights(String src_city,
			String dest_city, Date booking_date) throws AirLineException {
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		ArrayList<AirLineFlightInfoDTO> airDto = new ArrayList<AirLineFlightInfoDTO>();
		try {
			conn = DBconnection.getConnection();
			preparedStatement = conn.prepareStatement(IQueryMapper.GET_FLIGHTS);
			preparedStatement.setString(1, src_city);
			preparedStatement.setString(2, dest_city);
			preparedStatement.setDate(3,
					new java.sql.Date(booking_date.getTime()));
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				AirLineFlightInfoDTO bn = new AirLineFlightInfoDTO();
				bn.setFlightNo(resultSet.getString(1));
				bn.setAirLine(resultSet.getString(2));
				bn.setDept_city(resultSet.getString(3));
				bn.setArr_city(resultSet.getString(4));
				bn.setDept_date(resultSet.getDate(5));
				bn.setArr_date(resultSet.getDate(6));
				bn.setDept_time(resultSet.getString(7));
				bn.setArr_time(resultSet.getString(8));
				bn.setFirst_seats_fare(resultSet.getDouble(10));
				bn.setBus_seats_fare(resultSet.getDouble(12));
				airDto.add(bn);
			}
		} catch (AirLineException e) {
			throw new AirLineException("sorry not updated");
		} catch (SQLException e) {
			throw new AirLineException("sorry not updated");
		}
		return airDto;
	}

	@Override
	public Double findFirstSeatFare(String flightno) throws AirLineException {
		Double id = 0.0;
		Connection conn;
		PreparedStatement getid;

		try {
			conn = DBconnection.getConnection();
			getid = conn.prepareStatement(IQueryMapper.GET_FIRST_SEAT_FARE);
			getid.setString(1, flightno);
			ResultSet id1 = getid.executeQuery();
			while (id1.next()) {
				id = id1.getDouble(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return id;
	}

	@Override
	public Double findBusSeatFare(String flightno) throws AirLineException {
		Double id = 0.0;
		Connection conn;
		PreparedStatement getid;

		try {
			conn = DBconnection.getConnection();
			getid = conn.prepareStatement(IQueryMapper.GET_BUS_SEAT_FARE);
			getid.setString(1, flightno);
			ResultSet id1 = getid.executeQuery();
			while (id1.next()) {
				id = id1.getDouble(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return id;
	}

	@Override
	public int getBookingid() throws AirLineException {
		int id = 0;
		Connection conn;
		PreparedStatement getid;

		try {
			conn = DBconnection.getConnection();
			getid = conn.prepareStatement(IQueryMapper.GET_BOOKINGID);
			ResultSet id1 = getid.executeQuery();
			while (id1.next()) {
				id = id1.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return id;
	}

	@Override
	public void updateSeats(String flightNo, String class_type,
			int no_of_passengers) throws AirLineException {
		Connection conn;
		PreparedStatement getSTMNT;
		PreparedStatement getSTMNT1;
		int value = 0;
		int value2 = 0;
		int setResult = 0;
		try {
			conn = DBconnection.getConnection();
			if (class_type.equals("First Seat")) {

				getSTMNT = conn.prepareStatement(IQueryMapper.GET_FIRST_SEATS);
				getSTMNT.setString(1, flightNo);
				ResultSet set = getSTMNT.executeQuery();
				while (set.next()) {
					value = set.getInt(1);
				}
				value2 = value - no_of_passengers;
				getSTMNT1 = conn
						.prepareStatement(IQueryMapper.UPDATE_FIRST_SEATS);
				getSTMNT1.setString(2, flightNo);
				getSTMNT1.setInt(1, value2);
				setResult = getSTMNT1.executeUpdate();
				getSTMNT.close();
				getSTMNT1.close();
			} else if (class_type.equals("Bus Seat")) {
				getSTMNT = conn.prepareStatement(IQueryMapper.GET_BUS_SEATS);
				getSTMNT.setString(1, flightNo);
				ResultSet set = getSTMNT.executeQuery();
				while (set.next()) {
					value = set.getInt(1);
				}
				value2 = value - no_of_passengers;
				getSTMNT1 = conn
						.prepareStatement(IQueryMapper.UPDATE_BUS_SEATS);
				getSTMNT1.setString(2, flightNo);
				getSTMNT1.setInt(1, value2);
				setResult = getSTMNT1.executeUpdate();
				getSTMNT.close();
				getSTMNT1.close();
			}
			if (setResult != 1) {
				throw new AirLineException(
						"Sorry can not proccess your request");
			} else {

				conn.commit();
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	@Override
	public boolean validUser(String username, String password, String role)
			throws AirLineException {
		Connection conn;
		PreparedStatement validUserStmt = null;
		ResultSet validUserResult = null;

		try {
			conn = DBconnection.getConnection();
			validUserStmt = conn.prepareStatement(IQueryMapper.VALID_USER);
			validUserStmt.setString(1, role);
			validUserResult = validUserStmt.executeQuery();
			while (validUserResult.next()) {
				String user = validUserResult.getString(1);
				String pass = validUserResult.getString(2);
				if (user.equals(username) && pass.equals(password)) {

					return true;

				}
			}

		} catch (AirLineException | SQLException e) {
			// logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n" + e);
		}
		return false;
	}

	@Override
	public ArrayList<AirLineBookInfoDTO> showTicket(int bookingID)
			throws AirLineException {
		Connection conn;
		ResultSet resultSet = null;
		PreparedStatement preparedStatement = null;
		ArrayList<AirLineBookInfoDTO> bookDto = new ArrayList<AirLineBookInfoDTO>();
		boolean check = false;

		try {
			conn = DBconnection.getConnection();
			preparedStatement = conn
					.prepareStatement(IQueryMapper.GET_BOOKING_INFO);
			preparedStatement.setInt(1, bookingID);
			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				AirLineBookInfoDTO bn = new AirLineBookInfoDTO();
				bn.setBooking_id(resultSet.getInt(1));
				bn.setCust_email(resultSet.getString(2));
				bn.setNo_of_passengers(resultSet.getInt(3));
				bn.setClass_type(resultSet.getString(4));
				bn.setTotal_fare(resultSet.getDouble(5));
				bn.setSeat_number(resultSet.getString(6));
				bn.setCustomer_names(resultSet.getString(7));
				bn.setCreditcard_info(resultSet.getString(8));
				bn.setSrc_city(resultSet.getString(9));
				bn.setDest_city(resultSet.getString(10));
				bn.setFlightno(resultSet.getString(11));
				bn.setBooking_date(new Date(resultSet.getDate(12).getTime()));
				bookDto.add(bn);
				check = true;
			}
		} catch (AirLineException e) {
			throw new AirLineException("sorry not updated");
		} catch (SQLException e) {
			throw new AirLineException("sorry not updated");
		}

		if (check == true)
			return bookDto;
		else
			return null;
	}

	@Override
	public void deleteFlight(String flightno) throws AirLineException {
		Connection conn;

		PreparedStatement deleteStmt = null;
		try {
			conn = DBconnection.getConnection();
			deleteStmt = conn.prepareStatement(IQueryMapper.DELETE_FLIGHT);
			deleteStmt.setString(1, flightno);
			int delete = deleteStmt.executeUpdate();
			if (delete != 1) {
				// logger.error("Deletion Failed");
				throw new AirLineException("Deletion Failed");
			} else {
				System.out.println("\nRecord Deleted");
				conn.commit();
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
	}
	@Override
	public ArrayList<AirLineFlightInfoDTO> viewSchedule()
			throws AirLineException {

		Connection conn;
		PreparedStatement getViewStmt = null;
		ResultSet viewResult = null;
		ArrayList<AirLineFlightInfoDTO> view = new ArrayList<AirLineFlightInfoDTO>();

		try {
			conn = DBconnection.getConnection();
			getViewStmt = conn.prepareStatement(IQueryMapper.GET_FLIGHTS_ADMIN);
			viewResult = getViewStmt.executeQuery();
			while (viewResult.next()) {
				AirLineFlightInfoDTO dtoObj = new AirLineFlightInfoDTO();
				dtoObj.setFlightNo(viewResult.getString(1));
				dtoObj.setAirLine(viewResult.getString(2));
				dtoObj.setDept_city(viewResult.getString(3));
				dtoObj.setArr_city(viewResult.getString(4));
				dtoObj.setDept_date(viewResult.getDate(5));
				dtoObj.setArr_date(viewResult.getDate(6));
				dtoObj.setDept_time(viewResult.getString(7));
				dtoObj.setArr_time(viewResult.getString(8));
				dtoObj.setFirst_seats(viewResult.getInt(9));
				dtoObj.setFirst_seats_fare(viewResult.getInt(10));
				dtoObj.setBus_seats(viewResult.getInt(11));
				dtoObj.setBus_seats_fare(viewResult.getInt(12));
				view.add(dtoObj);
			}
		} catch (AirLineException | SQLException exception2) {
			// logger.error(exception2.getMessage());
			System.out.println(exception2);
		}

		return view;
	}
	@Override
	public void updateCity(String flightno,String src_city,String dest_city)throws AirLineException{
		Connection conn;
		PreparedStatement updateCityStmt = null;
		//ResultSet updateCityResult = null;
		conn = DBconnection.getConnection();
		try {
			updateCityStmt = conn.prepareStatement(IQueryMapper.UPDATE_PLACE);
			updateCityStmt.setString(1, src_city);	
			updateCityStmt.setString(2, dest_city);	
			updateCityStmt.setString(3, flightno);	
			int update = updateCityStmt.executeUpdate();
			if(update!=1){
				//logger.error("Deletion Failed");
				throw new AirLineException("Updating records Failed");
			}else {System.out.println("\nRecord Updated");}
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
	}
	@Override
	public void updateDate(String flightno,Date dep_date,Date arr_date)throws AirLineException{
		Connection conn;
		PreparedStatement updateDateStmt = null;
		//ResultSet updateDateResult = null;
		
		try {
			conn = DBconnection.getConnection();
			
			System.out.println(new java.sql.Date(dep_date.getTime()));
			updateDateStmt = conn.prepareStatement(IQueryMapper.UPDATE_DATE);
			updateDateStmt.setDate(1, new java.sql.Date(dep_date.getTime()));
			updateDateStmt.setDate(2, new java.sql.Date(arr_date.getTime()));	
			updateDateStmt.setString(3, flightno);	
			int update = updateDateStmt.executeUpdate();
			if(update!=1){
				//logger.error("Updation Failed");
				throw new AirLineException("Updating records Failed");
			}else {System.out.println("\nRecord Updated");}
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
	}
	@Override
	public void updateTime(String flightno,String dep_time, String arr_time)throws AirLineException{
		Connection conn;
		PreparedStatement updateTimeStmt = null;
		//ResultSet updateTimeResult = null;
		
		try {
			conn = DBconnection.getConnection();
			updateTimeStmt = conn.prepareStatement(IQueryMapper.UPDATE_TIME);
			updateTimeStmt.setString(1, dep_time);	
			updateTimeStmt.setString(2, arr_time);	
			updateTimeStmt.setString(3, flightno);	
			int update = updateTimeStmt.executeUpdate();
			if(update!=1){
				//logger.error("Deletion Failed");
				throw new AirLineException("Updating records Failed");
			}else {System.out.println("\nRecord Updated");}
		}catch (AirLineException | SQLException e) {
			//logger.error(e.getMessage());
			System.out.println("Sorry!!! Record Not Found\n"+e);
		}
	}
	@Override
	public void addFlight(AirLineFlightInfoDTO addFlightDto)
			throws AirLineException {
		Connection conn;
		PreparedStatement insert = null;
		conn = DBconnection.getConnection();
		try {

			insert = conn.prepareStatement(IQueryMapper.INSERT_FLIGHT);
			insert.setString(1, addFlightDto.getFlightNo());
			insert.setString(2, addFlightDto.getAirLine());
			insert.setString(3, addFlightDto.getDept_city());
			insert.setString(4, addFlightDto.getArr_city());
			insert.setDate(5, new java.sql.Date(addFlightDto.getDept_date()
					.getTime()));
			insert.setDate(6, new java.sql.Date(addFlightDto.getArr_date()
					.getTime()));
			insert.setString(7, addFlightDto.getDept_time());
			insert.setString(8, addFlightDto.getArr_time());
			insert.setInt(9, addFlightDto.getFirst_seats());
			insert.setDouble(10, addFlightDto.getFirst_seats_fare());
			insert.setInt(11, addFlightDto.getBus_seats());
			insert.setDouble(12, addFlightDto.getBus_seats_fare());
			int result = insert.executeUpdate();
			if (result != 1) {
				throw new AirLineException(
						"Sorry can not proccess your request");
			} else {
				System.out.println("Added Succesfully");
				conn.commit();
			}
		} catch (SQLException e) {
			System.out.println(e);
		}

	}
}