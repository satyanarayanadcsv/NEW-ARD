package com.cg.airline.presentation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.exception.AirLineException;
import com.cg.airline.service.AirLineServiceImpl;
import com.cg.airline.beans.AirLineFlightInfoDTO;

public class AirLineMain {
	public static Scanner in;
	public static AirLineServiceImpl service = new AirLineServiceImpl();
	public static String role;

	public static void main(String[] args) throws AirLineException,
			ParseException {
		in = new Scanner(System.in);
		System.out
				.println("------:Welcome to The AirLine Reservation System:-------");
		String choice = "initial";
		while (!choice.equals("4")) {
			System.out.println("Enter Your choice: ");
			System.out.println("1. customer");
			System.out.println("2. Admin");
			System.out.println("3. Airline Executive");
			System.out.println("4. Exit");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				getUser();
				break;
			case "2":
				admin();
				break;
			case "3":
				airlineExecutive();
				break;
			case "4":
				System.out.println("Thank You!");
				System.exit(0);
				break;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
	}

	static Boolean getUser() throws AirLineException, ParseException {

		in = new Scanner(System.in);
		String choice = "initial";
		while (!choice.equals("4")) {
			System.out.println("1. Book Ticket");
			System.out.println("2. Search Flight");
			System.out.println("3. View Ticket");
			System.out.println("4. Return to Main Menu");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				bookTicket();
				break;
			case "2":
				searchFlight();
				break;
			case "3":
				viewTicket();
				break;
			case "4":
				return false;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
		return true;
	}

	static boolean admin() throws AirLineException, ParseException {
		role = "Administrator";
		boolean flag = false;
		while (flag == false) {
			if (validUser(role)) {
				flag = true;
				String choice = "initial";
				while (!choice.equals("6")) {
					System.out.println("1. Add New Flight");
					System.out.println("2. Delete Flight");
					System.out.println("3. View Flight Schedule");
					System.out.println("4. Update Flight Schedule");
					System.out.println("5. Search Flight");
					System.out.println("6. Logout");
					choice = in.next().trim();
					switch (choice) {
					case "1":
						addFlight();
						break;
					case "2":
						deleteFlight();
						break;
					case "3":
						viewSchedule();
						break;
					case "4":
						updateSchedule();
						break;
					case "5":
						searchFlight();
						break;
					case "6":
						return false;
					default:
						System.out.println("Please Select valid choice");
						break;
					}
				}
			} else {
				System.out.println("Enter Valid Username and Password");
				flag = validUser(role);
				if (flag == false) {
					System.out.println("Enter Valid Username and Password");
				}
			}
		}
		return true;
	}

	static boolean airlineExecutive() throws AirLineException {
		role = "Airline Executive";
		boolean flag = false;
		while (flag == false) {
			if (validUser(role)) {
				flag = true;
				in = new Scanner(System.in);
				String choice = "initial";
				while (!choice.equals("2")) {
					System.out.println("1. View Flight Schedule");
					System.out.println("2. Log out");
					choice = in.next().trim();
					switch (choice) {
					case "1":
						System.out
								.println("**********Available Schedule**********");
						viewSchedule();
						break;
					case "2":
						break;
					default:
						System.out.println("Please Select valid choice");
						break;

					}
				}
			} else {
				System.out.println("Enter Valid Username And Password");
				flag = validUser(role);
				if (flag == false) {
					System.out.println("Enter Valid Username and Password");
				}
			}
		}
		return true;
	}

	static boolean validUser(String role) throws AirLineException {
		in = new Scanner(System.in);
		String username;
		String password;
		System.out.println("Enter Username:");
		username = in.next();
		System.out.println("Enter Password:");
		password = in.next();
		return service.validUser(username, password, role);

	}

	private static void deleteFlight() throws AirLineException {
		System.out.println("Enter Flight Number: ");
		String flightno = in.next();
		service.deleteFlight(flightno);
	}

	private static boolean updateSchedule() throws AirLineException,
			ParseException {
		in = new Scanner(System.in);
		String choice = "initial";
		while (!choice.equals("4")) {
			System.out.println("1. Update Source-Destination City");
			System.out.println("2. Update Departure-Arrival  Date");
			System.out.println("3. Update Departure-Arrival By Time");
			System.out.println("4. Return to Previous Menu");
			choice = in.next().trim();
			switch (choice) {
			case "1":
				updateCity();
				break;
			case "2":
				updateDate();
				break;
			case "3":
				updateTime();
				break;
			case "4":
				return false;
			default:
				System.out.println("Please Select valid choice");
				break;
			}
		}
		return true;
	}

	private static void updateCity() throws AirLineException {
		System.out.println("Enter Flight Number: ");
		String flightno = in.next();
		System.out.println("Enter Updated Source City: ");
		String src_city = in.next();
		System.out.println("Enter Updated Destination City: ");
		String dest_city = in.next();
		service.updateCity(flightno, src_city, dest_city);
	}

	private static void updateDate() throws AirLineException, ParseException {
		System.out.println("Enter Flight Number: ");
		String flightno = in.next();
		System.out.println("Enter Updated Departure Date: ");
		String dep_date = in.next();
		System.out.println("Enter Updated Arrival Date: ");
		String arr_date = in.next();
		service.updateDate(flightno,
				new SimpleDateFormat("dd-MM-yyyy").parse(dep_date),
				new SimpleDateFormat("dd-MM-yyyy").parse(arr_date));
	}

	private static void updateTime() throws AirLineException {
		System.out.println("Enter Flight Number: ");
		String flightno = in.next();
		System.out.println("Enter Updated Departure Time(24HOUR FORMAT): ");
		String dep_time = in.next();
		System.out.println("Enter Updated Arrival Time(24HOUR FORMAT): ");
		String arr_time = in.next();
		service.updateTime(flightno, dep_time, arr_time);
	}

	private static void addFlight() throws AirLineException, ParseException {

		in = new Scanner(System.in);
		System.out.println("Enter  flight Number: ");
		String flightno = in.next();
		System.out.println("Enter Airline Name: ");
		String airline = in.next();
		System.out.println("Enter Source city: ");
		String src_city = in.next();
		System.out.println("Enter Destination city: ");
		String dest_city = in.next();
		System.out.println("Enter Departure Date(dd-mm-yyyy): ");
		String dep_date = in.next();
		System.out.println("Enter Arrival Date(dd-mm-yyyy): ");
		String arr_date = in.next();
		System.out.println("Enter Departure Time(24HOUR FORMAT): ");
		String dep_time = in.next();
		System.out.println("Enter Arrival Time(24HOUR FORMAT): ");
		String arr_time = in.next();
		System.out.println("Enter Number of Economy Class Seats: ");
		int eseats = in.nextInt();
		System.out.println("Enter Economy Class Seat Fare: ");
		double eseat_fare = in.nextInt();
		System.out.println("Enter Number of Business Class Seats: ");
		int bseats = in.nextInt();
		System.out.println("Enter Business Class Seat Fare: ");
		double bseat_fare = in.nextInt();

		AirLineFlightInfoDTO addFlightDto = new AirLineFlightInfoDTO();
		addFlightDto.setFlightNo(flightno);
		addFlightDto.setAirLine(airline);
		addFlightDto.setDept_city(src_city);
		addFlightDto.setArr_city(dest_city);
		addFlightDto.setDept_date(new SimpleDateFormat("dd-MM-yyyy")
				.parse(dep_date));
		addFlightDto.setArr_date(new SimpleDateFormat("dd-MM-yyyy")
				.parse(arr_date));
		addFlightDto.setDept_time(dep_time);
		addFlightDto.setArr_time(arr_time);
		addFlightDto.setFirst_seats(eseats);
		addFlightDto.setFirst_seats_fare(eseat_fare);
		addFlightDto.setBus_seats(bseats);
		addFlightDto.setBus_seats_fare(bseat_fare);
		service.addFlight(addFlightDto);
	}

	private static void viewSchedule() throws AirLineException {
		List<AirLineFlightInfoDTO> flightList = new ArrayList<AirLineFlightInfoDTO>();
		flightList = service.viewSchedule();

		if (flightList != null) {
			Iterator<AirLineFlightInfoDTO> itr = flightList.iterator();
			System.out
					.println("Flight No  Airline     Source     Destination  Departure Date   Arrival Date  "
							+ "Departure Time  Arrival Time  "
							+ "Economy Seats  Economy Fare  Business Seats  Business Fare");
			while (itr.hasNext()) {
				AirLineFlightInfoDTO dtoObj1 = (AirLineFlightInfoDTO) itr
						.next();
				System.out.println(dtoObj1.getFlightNo() + "  "
						+ dtoObj1.getAirLine() + "  " + dtoObj1.getDept_city()
						+ "  " + dtoObj1.getArr_city() + "  "
						+ dtoObj1.getDept_date() + "  " + dtoObj1.getArr_date()
						+ "  " + dtoObj1.getDept_time() + "  "
						+ dtoObj1.getArr_time() + "  "
						+ dtoObj1.getFirst_seats() + "  "
						+ dtoObj1.getFirst_seats_fare() + "  "
						+ dtoObj1.getBus_seats() + "  "
						+ dtoObj1.getBus_seats_fare());
			}

		} else
			System.out.println("No Schedule Available");
	}

	private static void viewTicket() throws AirLineException {
		int bookingID;
		System.out.println("Enter Booking Id");
		bookingID = in.nextInt();
		ArrayList<AirLineBookInfoDTO> bookDto = new ArrayList<AirLineBookInfoDTO>();
		bookDto = service.showTicket(bookingID);

		if (bookDto != null) {
			Iterator<AirLineBookInfoDTO> i = bookDto.iterator();
			while (i.hasNext()) {
				AirLineBookInfoDTO obj = (AirLineBookInfoDTO) i.next();
				System.out.println(obj.getFlightno());
				System.out.println(obj.getCustomer_names());
				System.out.println(obj.getSrc_city());
				System.out.println(obj.getDest_city());
				System.out.println(obj.getSeat_number());
				System.out.println(new SimpleDateFormat("MM-dd-yyyy")
						.format(obj.getBooking_date()));
			}
		} else {
			System.out.println("Not Available");
		}

	}

	private static void searchFlight() throws AirLineException, ParseException {
		System.out.println("Enter Source city");
		String src_city = in.next();
		System.out.println("Enter Destination city");
		String dest_city = in.next();
		System.out.println("Enter Date");
		String booking_date = in.next();

		ArrayList<AirLineFlightInfoDTO> airDto = new ArrayList<AirLineFlightInfoDTO>();
		airDto = service.showFlights(src_city, dest_city, new SimpleDateFormat(
				"dd-MM-yyyy").parse(booking_date));

		if (airDto != null) {
			System.out
					.println("FlightNo  AirLine  DeptCity  ArrCity  DeptDate  ArrDate  DeptTime  ArrTime  FirstFare  BusFare");
			Iterator<AirLineFlightInfoDTO> i = airDto.iterator();
			while (i.hasNext()) {
				AirLineFlightInfoDTO obj = (AirLineFlightInfoDTO) i.next();
				System.out.print(obj.getFlightNo() + "	");
				System.out.print(obj.getAirLine() + "	 ");
				System.out.print(obj.getDept_city() + "	");
				System.out.print(obj.getArr_city() + "	");
				System.out.print(obj.getDept_date() + "	");
				System.out.print(obj.getArr_date() + "	");
				System.out.print(obj.getDept_time() + "	");
				System.out.print(obj.getArr_time() + "	");
				System.out.print(obj.getFirst_seats_fare() + "	");
				System.out.print(obj.getBus_seats_fare() + "\n");
			}
			System.out.println();
		} else {
			System.out.println("Not Available");
		}

	}


	static void bookTicket() throws AirLineException, ParseException {
		
		//int no_of_passengers;
		String class_type;
		double total_fare;
		String seat_number;
		String creditcard_info;
		String src_city;
		String dest_city;
		String flightno;
		String custMail;
		Double firstSeatFare;
		Double busSeatFare;
		String booking_date;
		String customer_names;
		int booking_id;
		AirLineBookInfoDTO dto = new AirLineBookInfoDTO();

		System.out.println("Enter Source city");
		src_city = in.next();
		if (service.ValidateString(src_city) == true)
		{
			break;
			
		} else {
			System.out.println("invalid source city");

		System.out.println("Enter Destination city");
		dest_city = in.next();
		if (service.ValidateString(dest_city) == true)
		{
			break;
			
		} else {
			System.out.println("invalid destination city");
		System.out.println("Enter Date");
		booking_date = in.next();

		ArrayList<AirLineFlightInfoDTO> airDto = new ArrayList<AirLineFlightInfoDTO>();
		airDto = service.showFlights(src_city, dest_city, new SimpleDateFormat(
				"dd-MM-yyyy").parse(booking_date));

		if (airDto != null) {
			System.out
					.println("FlightNo  AirLine  DeptCity  ArrCity  DeptDate  ArrDate  DeptTime  ArrTime  FirstFare  BusFare");
			Iterator<AirLineFlightInfoDTO> i = airDto.iterator();
			while (i.hasNext()) {
				AirLineFlightInfoDTO obj = (AirLineFlightInfoDTO) i.next();
				System.out.print(obj.getFlightNo() + "	");
				System.out.print(obj.getAirLine() + "	 ");
				System.out.print(obj.getDept_city() + "	");
				System.out.print(obj.getArr_city() + "	");
				System.out.print(obj.getDept_date() + "	");
				System.out.print(obj.getArr_date() + "	");
				System.out.print(obj.getDept_time() + "	");
				System.out.print(obj.getArr_time() + "	");
				System.out.print(obj.getFirst_seats_fare() + "	");
				System.out.print(obj.getBus_seats_fare() + "\n");
			}
			System.out.println();
		} else {
			System.out.println("Not Available");
		}

		System.out.println("Enter  flight Number");
		flightno = in.next();
		if (service.ValidateFlightNo(flightno) == true)
		{
			break;
			
		} else {
			System.out.println("invalid flightno pattern");
		firstSeatFare = service.findFirstSeatFare(flightno);
		busSeatFare = service.findBusSeatFare(flightno);

		System.out.println("Enter email");
		custMail = in.next();
		if (service.ValidateMailId(custMail) == true)
		{
			break;
			
		} else {
			System.out.println("invalid mailid pattern");
		System.out.println("Enter no of passenegers");
	int no_of_passengers = in.nextInt();
		String t= Integer.toString(no_of_passengsers);
		if (service.ValidateNoOfPassengers(t)==true)
		{
			break;
			
		} else {
			System.out.println("invalid no of passengers");
		String choice = "initial";
		while (true) {
			System.out.println("Enter Class Type");
			System.out.println("1.First Seat");
			System.out.println("2.Bus Seat");
			choice = in.next();
			if (choice.equals("1")) {
				class_type = "First Seat";
				total_fare = no_of_passengers * firstSeatFare;
				break;
			} else if (choice.equals("2")) {
				class_type = "Bus Seat";
				total_fare = no_of_passengers * busSeatFare;
				break;
			} else {
				System.out.println("Invalid choice");
			}
		}

		System.out.println("Enter Seat Numbers");
		seat_number = in.next();

		System.out.println("Enter Customer Names");
		customer_names = in.next();
		if (service.ValidateString(src_city) == true)
		{
			break;
			
		} else {
			System.out.println("invalid customer name pattern");

		System.out.println("Enter creditcard info");
		creditcard_info = in.next();

		dto.setCust_email(custMail);
		dto.setClass_type(class_type);
		dto.setCreditcard_info(creditcard_info);
		dto.setDest_city(dest_city);
		dto.setSrc_city(src_city);
		dto.setFlightno(flightno);
		dto.setNo_of_passengers(no_of_passengers);
		dto.setTotal_fare(total_fare);
		dto.setSeat_number(seat_number);
		dto.setBooking_date(new SimpleDateFormat("dd-MM-yyyy")
				.parse(booking_date));
		dto.setCustomer_names(customer_names);
		service.bookTicket(dto);
		booking_id = service.getBookingid();
		dto.setBooking_id(booking_id);
		if (booking_id != 0) {
			service.updateSeats(dto.getFlightno(), dto.getClass_type(),
					no_of_passengers);
		}
		System.out.println("Bookingss Id :" + booking_id);
	
		}
		