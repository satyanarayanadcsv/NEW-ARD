package com.cg.airline.util;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.airline.exception.AirLineException;

public class DBconnection {
	
	private static Connection conn = null;
	public static Connection getConnection() throws AirLineException{
		if(conn == null){
			try{
				File src = new File("Resources/jdbc.properties");
				FileInputStream fis = new FileInputStream(src);
				
				Properties pro = new Properties();
				
				pro.load(fis);
				
				String drive = pro.getProperty("driver");
				String dburl = pro.getProperty("dbURL");
				String uname = pro.getProperty("username");
				String pword = pro.getProperty("password");
				
				Class.forName(drive);
				conn= DriverManager.getConnection(dburl, uname, pword);
				conn.commit();
			}
			catch(FileNotFoundException fe)
			{
				throw new AirLineException("Unable to find Properties file."+ fe.getMessage());
			}
			catch(ClassNotFoundException ce)
			{
				throw new AirLineException("Driver class Not found."+ ce.getMessage());
			}
			catch(IOException ie)
			{
				throw new AirLineException("Problem ocuured while reading properties"+ ie.getMessage());
			}
			catch(SQLException se)
			{
				throw new AirLineException("Sql statement not correct."+ se.getMessage());
			}
		}
		return conn;
	}
	
}
