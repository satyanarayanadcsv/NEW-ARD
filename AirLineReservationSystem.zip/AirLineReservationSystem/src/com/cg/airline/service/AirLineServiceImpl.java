package com.cg.airline.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.regex.Pattern;

import com.cg.airline.beans.AirLineBookInfoDTO;
import com.cg.airline.beans.AirLineFlightInfoDTO;
import com.cg.airline.dao.AirLineDAOImpl;
import com.cg.airline.exception.AirLineException;

public class AirLineServiceImpl implements IAirLineService{
	AirLineDAOImpl dao;
	
	
	public AirLineServiceImpl() {
		dao =new AirLineDAOImpl();
	}
	
	@Override
	public void bookTicket(AirLineBookInfoDTO dto) throws AirLineException{
		dao.bookTicket(dto);
	}
	
	@Override
	public ArrayList<AirLineFlightInfoDTO> showFlights(String src_city, String dest_city, Date booking_date) throws AirLineException{
		return dao.showFlights(src_city, dest_city, booking_date);
	}
	
	@Override
	public Double findFirstSeatFare(String flightno) throws AirLineException{
		return dao.findFirstSeatFare(flightno);
	}
	@Override
	public Double findBusSeatFare(String flightno) throws AirLineException{
		return dao.findBusSeatFare(flightno);
	}
	@Override
	public int getBookingid() throws AirLineException{
		// TODO Auto-generated method stub
		return dao.getBookingid();
	}
	@Override
	public void updateSeats(String string, String class_type, int no_of_passengers) throws AirLineException{
		dao.updateSeats(string, class_type, no_of_passengers);	
	}
	@Override
	public ArrayList<AirLineBookInfoDTO> showTicket(int bookingID) throws AirLineException{
		return dao.showTicket(bookingID);
	}
	@Override
	public boolean validUser(String username,String password, String role)throws AirLineException{
		return dao.validUser(username,password, role);
	}
	@Override
	public void addFlight(AirLineFlightInfoDTO addFlightDto) throws AirLineException{
		dao.addFlight(addFlightDto);
	}
	@Override
	public void deleteFlight(String flightno) throws AirLineException{
		dao.deleteFlight(flightno);
	}
	@Override
	public ArrayList<AirLineFlightInfoDTO> viewSchedule() throws AirLineException{
		return dao.viewSchedule();
	}
	@Override
	public void updateCity(String flightno,String src_city,String dest_city)throws AirLineException{
		 dao.updateCity(flightno,src_city,dest_city);
	}
	@Override
	public void updateDate(String flightno,Date dep_date,Date arr_date)throws AirLineException{
		dao.updateDate(flightno,dep_date,arr_date);
	}
	@Override
	public void updateTime(String flightno,String dep_time, String arr_time)throws AirLineException{
		dao.updateTime(flightno,dep_time,arr_time);
	}
	public boolean ValidateString(String name) {
		// TODO Auto-generated method stub
		String namePattern = "[A-Za-z]{1,*}";
		if(Pattern.matches(namePattern,name))
			return true;
		return false;
	}

	public boolean ValidatePassword(String password) {
		String namePattern = "[A-Za-z0-9]{1,*}";
		if(Pattern.matches(namePattern,password))
			return true;
		return false;
	}
	public boolean ValidateMailId(String mailId) {
		// TODO Auto-generated method stub
		String mailIdPattern = "[A-Za-z0-9]{1,20}[@][A-Za-z]{3,15}[.][A-Za-z]{1,15}";
		if(Pattern.matches(mailIdPattern,mailId))
			return true;
		return false;
	}
	public boolean ValidateFlightNo(String flightno){
		String flightNoPattern ="[A-Za0-z0-9]{3,4}-[A-Za0-z0-9]{3,4}";
		if(Pattern.matches(flightNoPattern, flightno))
		return true;
		return false;
		
	}
	public boolean ValidateNoOfPassengers(String noofpassengers){
		String NoOfPassengersPattern ="[0-9]{1,*}";
		
		if(Pattern.matches(NoOfPassengersPattern, noofpassengers))
		return true;
		return false;
		
	}

}